import sublime, sublime_plugin, datetime, re, sys, traceback

done_string = 'DONE:'
linkedString = 'LINKED:'
s_colon_thresh = 0
tidyIndentRep = "     "
tidyIndentEnd = " -> "

class GotoDoneCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		print ("goto done")
		pos_orig = self.view.sel()[0]
		scope = dest_find_or_create(self, edit, False)
		# v = self.view
		# v.sel().clear()
		# v.sel().add(scope)
		# return
		pos = scope.b - 1
		sel = self.view.sel()
		sel.clear()
		if pos == pos_orig.a:
			pos = 0;
		sel.add(sublime.Region(pos, pos))
		self.view.show_at_center(pos)

class GotoNextHeadingCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		pos = 0
		sel = self.view.sel()
		target = None

		for s in sel:
			#link_formats = (("->\[(.+)\]", "(?<!->)\[", "\]"), ("(?<!->)\[(.+)\]", "->\[", "\]"))
			link_formats = (("\[(.+)\]", "[", "]"),)
			for link_format in link_formats:
				line = self.view.lines(s)[0]
				start = self.view.find("[^\s]", line.begin())
				line_text = self.view.substr(line)
				#print "searching for " + link_format[0] + " in " + line_text
				# print "link format" + link_format[0]
				m = re.search(link_format[0], line_text)
				if not m:
					print "no match"
					continue
				link = m.group(1)
				print "link = " + link
				target = link_format[1] + link + link_format[2]
				break
			pos = s.begin()
			break

		if target:
			pos = self.view.text_point(self.view.rowcol(pos)[0] + 1, 0)
			# print "target is: " + target
			found = self.view.find(target, pos + 1, sublime.LITERAL | sublime.IGNORECASE)
			if not found:
				found = self.view.find(target, 0, sublime.LITERAL | sublime.IGNORECASE)
			if not found:
				print "target not found"
				return
			pos = found.begin()
			sel.clear()
			sel.add(found)
			self.view.show_at_center(pos)
			self.view.window().run_command("slurp_find_string")
			return

		# print "main"
		for i in range(2):
			found1 = self.view.find("^.+_\s*$", pos+1)
			found2 = self.view.find("^#", pos+1)
			found3 = self.view.find("^[A-Za-z]{3} \d{2} [A-Za-z]{3} \d{4}", pos+1)
			found = None
			if (found1 != None):
				found = found1
			if (found2 != None):
				found = min(found, found2)
			if (found3 != None):
				found = min(found, found3)
			if found == None:
				pos = -1
				continue
			# found = min(found, )
			# print found
			pos = found.begin()
			sel.clear()
			sel.add(sublime.Region(pos, pos))
			self.view.show_at_center(pos)
			break

class InsertDateCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		date = datetime.date.today().strftime('%Y%b%d').lower()
		for region in reversed(self.view.sel()):
			self.view.replace(edit, region, "")
			self.view.insert(edit, region.begin(), date)

class InsertTimeCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		mydate = datetime.datetime.today().strftime('%H:%M').lower()
		for region in reversed(self.view.sel()):
			self.view.replace(edit, region, "")
			self.view.insert(edit, region.begin(), mydate)

class InsertDateRetCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		date = datetime.date.today().strftime('%a %d %b %Y\n\n')
		for region in reversed(self.view.sel()):
			self.view.replace(edit, region, "")
			self.view.insert(edit, region.begin(), date)
		self.view.run_command("move", {"by": "lines", "forward": False})
		#self.view.run_command("move", {"by": "lines", "forward": False})

class InsertDayCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		days = ["#mon", "#tue", "#wed", "#thu", "#fri", "#sat", "#sun"]
		for region in reversed(self.view.sel()):
			testRegion = sublime.Region(region.begin() - 4, region.begin())
			test = self.view.substr(testRegion).lower()
			if test in days:
				next_day = days[(days.index(test) + 1) % len(days)]
				self.view.replace(edit, testRegion, next_day)
			else:
				date = datetime.date.today().strftime('#%a').lower()
				self.view.replace(edit, region, "")
				self.view.insert(edit, region.begin(), date)

def undecorate(str):
	# str = str[0:4].replace("-> [", "") + str[4:]
	return str.lstrip("[+*-%@= ").rstrip(":] ")

def uncolon(str):
	# str = str[0:4].replace("-> [", "") + str[4:]
	return str.rstrip(": ")

# return region of dest section body
def dest_find_or_create(self, edit, source_for_link):
	v = self.view
	sel = v.sel()	
	if source_for_link:
		found = v.find(linkedString, 0, sublime.LITERAL)
		if found == None:
			return sublime.Region(0, 0) # couldn't find linked section; todo create it
		(row, col) = v.rowcol(found.b)
		pos = v.text_point(row+1, 0)
		linked_area = sublime.Region(pos, v.size())
		assert(len(source_for_link.kids) > 0)
		link_sought = "[" + source_for_link.kids[0].line + "]" 
		# print "seeking " + link_sought
		found = v.find(link_sought, pos, sublime.LITERAL)
		if found == None: # couldn't find existing link
			pos = v.size()
			v.insert(edit, pos, link_sought + "\n");
			return sublime.Region(pos, v.size()) 
		else: # found link
			return get_extended_to_hier(v, sublime.Region(found.a, found.b), True)
			# return sublime.Region(found.a, found.b)

	else:
		date = datetime.date.today().strftime('%a %d %b %Y')
		find = done_string + '\n\n' + date
		found = v.find(find, 0, sublime.LITERAL)
		if found == None:
			# print "no today"
			found = v.find(done_string, 0, sublime.LITERAL)
			if found == None:
				# print "no done"
				return sublime.Region(0, 0) 
			else:
				# print "found done section, creating date"
				(row, col) = v.rowcol(found.begin())
				# print row + 2
				pos = v.text_point(row+2, 0)
				v.insert(edit, pos, date + "\n\n")
				# sel.clear()
				# sel.add(sublime.Region(pos, pos))
				row += 3
				pos = v.text_point(row, 0)
				return sublime.Region(pos, pos+1)
		else:
			# print "found today's date"
			(row1, col1) = v.rowcol(found.begin())
			pos = v.text_point(row1+3, 0)
			scope_start = v.text_point(row1+3, 0)
			found2 = v.find("^[A-Za-z]{3} \d{2} [A-Za-z]{3} \d{4}", pos)
			# if (v.line(found2
			(row2, col2) = v.rowcol(found2.a)
			scope_end = found2.a
			for row in reversed(xrange(row1, row2)):
				line = v.substr(v.line(v.text_point(row, 0)))
				if line[0:2] == "--":
					ind = count_indent_tabs(line)
					while row < row2 - 1:
						row = row + 1
						line = v.substr(v.line(v.text_point(row, 0)))
						print line, count_indent_tabs(line)
						ind2 = count_indent_tabs(line)
						if (ind2 <= ind):
							break
					scope_start = v.text_point(row, 0)
					break
			scope = sublime.Region(scope_start, scope_end)
			return scope

class Node:
	def __init__(self, line = "<ROOT>", virtual = 0):
		self.kids = []
		self.line = line
		self.virtual = virtual

	def __repr__(self, indent = 0):
		s = "    " * indent
		s += "{"*self.virtual + "'" + self.line + "'" + "}"*self.virtual + "\n"
		s += "".join(kid.__repr__(indent + 1) for kid in self.kids)
		return s

	@staticmethod
	def test():
		root = Node("root")
		root.kids.append(Node("child1"))
		root.kids[-1].kids.append(Node("grandchildof1"))
		root.kids.append(Node("child2"))
		root.kids[-1].kids.append(Node("grandchildof2"))
		root.kids.append(Node("child3"))
		print root

	def bstrip(self):
		if len(self.kids) == 0: return
		if self.kids[-1].line == "" and len(self.kids[-1].kids) == 0:
			del self.kids[-1]
		else:
			self.kids[-1].bstrip()

	def split_colons(self):
		# pos = self.line.find(': ')
		while (1):
			m = re.match("(.*) : +(.+)", self.line)
			if m: # and m.start(2) < s_colon_thresh:
				# print m.start(2)
				# print m.group(1)
				# print m.group(2)
				# print "---"
				self.line = m.group(1)
				kid = Node(m.group(2))
				kid.kids = self.kids
				self.kids = [kid]
			else:
				break
		for kid in self.kids:
			kid.split_colons()

	def join_colons(self, level):
		for kid in self.kids:
			kid.join_colons(level + 1)
		if level >= 0 and len(self.line) < s_colon_thresh and len(self.kids) == 1:
			kid = self.kids[0]
			self.line = uncolon(self.line) + " : " + kid.line
			# print self.line
			self.kids = kid.kids
			del kid

	# eat everything > my level using peeking
	def parse(self, level, lines, inline = 0, tabs_virtual = 0):
		while 1:
			if len(lines) == 0: return
			
			line = lines[0] # peek
			tabs = count_indent_tabs(line)
			if tabs < 0:
				lines.pop(0) # ignore blank lines
				continue
			# print "lev {0}: parsing {1}-tabbed: '{2}'".format(level, tabs, line if line else "<null line>")
			# if 0 <= tabs <= level or (tabs < 0 and len(self.kids) == 0):   breaks if first child blank
			if tabs + tabs_virtual <= level:
				# print "reject"
				return # not a child of us, return to let parent process it

			lines.pop(0) # we agree to process as a child
			line2 = line[tabs:]
			kid = Node(line2)

			# make kid have a kid of its own if it contains a colon then more text
			kid_c = kid
			tabs_virtual_child = tabs_virtual
			while inline:
				pos = kid_c.line.find(' : ')
				line_kid = kid_c.line[pos+3:].lstrip() if pos >= 0 else ""
				if line_kid == "": break
				# todo trim spaces from kidkid
				# tabs_virtual_child += 1
				kidkid = Node(line_kid)
				kid_c.line = kid_c.line[:pos]
				kid_c.kids.append(kidkid)
				kid_c = kidkid

			self.kids.append(kid)
			self.kids[-1].parse(tabs, lines, inline, tabs_virtual_child)

#test01: inline
#test02
		#test1
			#test2
	#test2: test21
		#test3

	def get_text(self, level, inline = 0, skip = True, tidy = False):
		s = ""
		kid_lines = "".join(kid.get_text(level + 1, inline, skip = False, tidy = tidy) for kid in self.kids)
		# print "count = {0}, self level = {1}, inline = {2}".format(kid_lines.count('\n'), level, inline)
		# print "kid_lines = " + kid_lines
		if tidy:
			def tab(n):	return (tidyIndentRep*(n-1) + tidyIndentEnd) if n > 0 else ""
		else:
			def tab(n):	return "\t"*n
		sl = self.line
		if tidy:
			if sl[-5:-3].isdigit() and sl[-3] == ":" and sl[-2:].isdigit():
				sl = sl[:-5]
		if inline and not skip and len(sl) < s_colon_thresh and kid_lines.count('\n') == 1:
			s += tab(level) + undecorate(sl) + ": " + kid_lines.lstrip()
		else:
			if not skip:
				s += tab(level) + sl + "\n"
			s += kid_lines
		# print "s = " + s
		return s

	def append_real(self, date):
		if not self.virtual:
			self.line = self.line.rstrip() + " " + date
			return
		for kid in self.kids:
			kid.append_real(date)

	def merge(self, other, date = None):
		# print "merging {0} into {1}".format(other, self)
		kid_lines = [undecorate(kid.line) for kid in self.kids]
		for incoming in other.kids:
			other_line2 = undecorate(incoming.line)
			if other_line2 in kid_lines:
				i = len(kid_lines) - 1 - kid_lines[::-1].index(other_line2)
				# print "merging kids[{0}]".format(i)
				taker = self.kids[i]
				#if not incoming.virtual:
					# print "DONE appended to {0}".format(taker)
					#taker.line += " DONE " + date
				taker.merge(incoming, date)
			else:
				# print "appending {0} to kids of {1}".format(incoming, self)
				if date:
					incoming.append_real(date)
				self.kids.append(incoming)

	def coalesce(self):
		k = 0
		while k < len(self.kids) - 1:
			# print "testing {0} against {1}".format(self.kids[k].line, self.kids[k+1].line)
			if self.kids[k].line == self.kids[k+1].line:
				# print("merging {0}".format(self.kids[k].line))
				self.kids[k].merge(self.kids[k+1])
				del self.kids[k+1]
			else:
				k += 1

	# returns the row above
	def add_ancestors(self, level, pos, v, level_target, nowrite = False):
		if len(self.kids) == 0: return
		row, col = v.rowcol(pos)
		col = 0 # so that text_point always works
		row -= 1
		# print level_target 
		# print row+1, level
		while level > level_target and row >= 0:
			line = v.line(v.text_point(row, col))
			line_text = v.substr(line)
			tabs = count_indent_tabs(line_text)
			# print row+1, level, tabs, line_text
			if tabs < level and tabs >= 0:
				level = tabs
				if not nowrite:
					line2 = line_text[tabs:]
					kid = Node(line2, 1)
					kid.kids = self.kids
					self.kids = [kid]
			row -= 1
		return row

	# replace kid0 with "kid0: kid" for each kid of kid0
	def distribute_kid0(self):
		kid0 = self.kids[0]
		# del kids[0]
		for kid in kid0.kids:
			kid.line = undecorate(kid0.line) + " : " + kid.line
		del self.kids[0]
		self.kids[0:0] = kid0.kids
		# print kid0


def prependLinesWith(self, edit, prefix, newline=False):
	v = self.view
	sel_orig = [r for r in v.sel()]
	o = 0;
	lines = []
	sat = True
	for region in sel_orig:
		for line in v.lines(region):
			lines.append(line)
			# print line
			start = v.find("[^\s]", line.begin())
			if not (start.begin() < line.end() and v.substr(sublime.Region(start.begin(), start.begin() + len(prefix))) == prefix):
				sat = False
	for line in lines:
		pos = line.begin() + o
		start = v.find("[^\s]", pos)
		print start
		if start.begin() >= line.end():
			start = sublime.Region(line.end(), line.end())
		# print "start.begin() ", start.begin()
		# print "line.begin() ", line.begin()
		# print "line.end() ", line.end()
		# print "o", o
		if True: # start.begin() < line.end() + o:
			print "here"
			if sat:
				v.erase(edit, sublime.Region(start.begin(), start.begin()+len(prefix)))
				o -= len(prefix)
			else:
				print start.begin() < line.end() + o, v.substr(sublime.Region(start.begin(), start.begin() + len(prefix))) == prefix
				if not (start.begin() < line.end() + o and v.substr(sublime.Region(start.begin(), start.begin() + len(prefix))) == prefix):
					v.insert(edit, start.begin(), prefix)
					o += len(prefix)
	if newline and len(sel_orig) == 1 and sel_orig[0].begin() == sel_orig[0].end():
		v.run_command("move", {"by": "lines", "forward": True})

class prepend_lines_with(sublime_plugin.TextCommand):
	def run(self, edit, x = ""):
		prependLinesWith(self, edit, x)

class swap_anchor(sublime_plugin.TextCommand):
	def run(self, edit):
		v = self.view
		sel = v.sel()
		sel2 = [r for r in sel]
		sel.clear()
		for s in sel2:
			# print s.a, s.b
			sel.add(sublime.Region(s.b, s.a))
		# for s in self.view.sel():
			# print s.a, s.b

class encompass_curly(sublime_plugin.TextCommand):
	def run(self, edit):

		v = self.view
		sel_orig = [r for r in v.sel()]
		for region in reversed(sel_orig):

			lines = v.lines(region)

			# measure indentation
			tabs = (count_indent_tabs(v.substr(line)) for line in lines)
			indent = min(tab for tab in tabs if tab >= 0) - 1

			# encompass line start, end and newlines
			block = sublime.Region(lines[0].begin(), lines[-1].end())

			v.insert(edit, block.end(), "\n" + "\t"*indent + "}")
			v.insert(edit, block.begin(), "\t"*indent + "{\n")

class copy_unindented(sublime_plugin.TextCommand):
	def run(self, edit):
		v = self.view
		lines_text = []
		indent = 999
		for region in v.sel():
			for line in v.lines(region):
				line_text = v.substr(line)
				indent = min(indent, count_indent_tabs(line_text))
				lines_text.append(line_text)
		# print lines_text
		# print indent
		lines_text = [l[indent:] for l in lines_text]
		sublime.set_clipboard('\n'.join(lines_text))
		# print lines_text
		return

class extendSelUpToFirstLevel(sublime_plugin.TextCommand):
	def run(self, edit):

		def extend_up(row):
			v = self.view
			level = -1
			while level < 0 and row >= 0:
				pos = v.text_point(row, 0)
				level = count_indent_tabs(v.substr(v.line(pos)))
				row -= 1
				# print level, row
			while row >= 0:
				pos = v.text_point(row, 0)
				level_test = count_indent_tabs(v.substr(v.line(pos)))
				if level_test < level:
					break
				row -= 1
			row += 1
			return row
			
		v = self.view
		sel_orig = [r for r in v.sel()]
		v.sel().clear()
		for region in sel_orig:
			row, col = v.rowcol(region.a)
			row2, col2 = v.rowcol(region.b)
			print row+1, row2+1
			row_new = extend_up(row)
			if row_new == row:
				row_new = extend_up(row-1)
			pos = v.text_point(row_new, 0)
			region_new = sublime.Region(pos, max(region.a, region.b))
			v.sel().add(region_new)

def addToNum(self, edit, d):
	sel_orig = [r for r in self.view.sel()]
	o = 0;
	lines = []
	for region in sel_orig:
		for line in self.view.lines(region):
			lines.append(line)
	for line in lines:
		pos = line.begin() + o
		num = self.view.find("(-?\d+)", pos)
		prev = self.view.substr(num)
		next = str(int(prev) + d)
		# print next, len(str(next))
		self.view.replace(edit, num, next)

class CdeIncrementCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		addToNum(self, edit, 1)

class CdeDecrementCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		addToNum(self, edit, -1)

def get_extended_to_hier(v, region, extend):
	# if not extend and region.a != region.b:
	# 	# don't change
	# 	return region

	# empty region: select hierarchy

	(row0, col0) = v.rowcol(region.a)
	(row, col) = v.rowcol(region.b)

	# causes repeated extending to fail (shift+ctrl+down)
	if not extend and row > row0 and col == 0:
	 	(row, col) = v.rowcol(region.b-1)

	(row_last, col_last) = v.rowcol(v.size())
	#sel.add(sublime.Region(region.a, region.b+2))
	line_reg = v.line(v.text_point(row, col))
	tabs0 = count_indent_tabs(v.substr(line_reg))
	if tabs0 == -1:
		if extend:
			row += 1
			line_reg = v.line(v.text_point(row, col))
			tabs0 = count_indent_tabs(v.substr(line_reg))
		else:
			# blank line
			# print "adding {0}".format(v.substr(region))
			return region

	row1 = row+1
	# print "tabs {0}".format(tabs0)
	# import pprint
	# pprint.pprint(locals())
	# print "row_last = {0}"
	# import sys
	# print sys.version_info
	blanks = 0
	while True:
		row += 1
		if (row > row_last):
			break
		line_reg = v.line(v.text_point(row, 0))
		tabs = count_indent_tabs(v.substr(line_reg))
		# print "examining line (t={0}): ".format(tabs) + v.substr(line_reg) 
		if tabs < 0 or tabs > tabs0:
			blanks = blanks + 1 if tabs < 0 else 0
			# print "row1 -> ", row+1
			row1 = row+1
		else:
			break
	
	# print "blanks ", blanks
	row1 -= blanks
	# print "setting row range to be {0} -> {1}".format(row0+1, row1+1)
	return sublime.Region(v.text_point(row0, 0), v.text_point(row1, 0))

def sel_hier(self, edit, extend = True):
	# print "-----"
	v = self.view
	sel_orig = [r for r in v.sel()]
	sel = v.sel()
	sel.clear()

	for region in sel_orig:
		region = sublime.Region(*sorted([region.a, region.b]))
		sel.add(get_extended_to_hier(v, region, extend))

class SelectHierarchyCommand(sublime_plugin.TextCommand):
	def run(self, edit):
		sel_hier(self, edit, True)

def count_indent_tabs(line_text):
	# print "counting indent tabs for: " + line_text
	m = re.search("[^\t]", line_text)
	tabs = 0
	if m:
		# print "line {0}: -----> {1}".format(line_text, m.start())
		return m.start()
	else:
		# print "returning -1"
		return -1

# above:
#  -1: to last sibling of ancestor
#  0: to DONE section
#  1 = to above immediate ancestor, broken out with duplicated heading
#  2 = to above furthest ancestor (top level) , broken out with duplicated heading
#  3 = to above furthest ancestor (top level) , broken out with duplicated heading, using colon
def move_region(self, edit, region, clear_only, link, copy_only, above, date):

# build source tree
	# Node.test()
	v = self.view
	source_tree = Node("source")
	source_lines = v.lines(region)
	source_block = [v.substr(line) for line in source_lines]
	source_tree.parse(-1, source_block)
	# print source_tree
	# return
	tabs = count_indent_tabs(v.substr(source_lines[0]))
	level_target = max(tabs-1, 0) if above >= 2 or above == -1 else 0
	dest_row = source_tree.add_ancestors(tabs, region.a, v, level_target, above == -1) + 1
	#print dest_row
	source_tree.line = "source+an" # only for the human readable repr
	#print source_tree
	#return

# copy
	if copy_only:
		sublime.set_clipboard(source_tree.get_text(-1, 1, tidy = True))
		return

# clear source lines
	# print "clearing"
	if above != -1: # otherwise clear after
		for line in reversed(source_lines):
			v.erase(edit, v.full_line(line))
	if clear_only:
		return

# find or create dest area
	if above:
		# we're moving the block above current parent or furthest ancestor
		# or moving it to bottom of current parent in case where above = -1
		# print "dest_row", dest_row

		# if moving an unindented block above, interpret this as wanting to move it to the top of the file
		if tabs == 0:
			dest_row = 0
		dest_pos = v.text_point(dest_row, 0)
		dest_region = sublime.Region(dest_pos, dest_pos)
		indent = -1

		if above == -1:
			if tabs == 0: # top level block already, dest_row/region won't be meaningful, move to underneath the next heading
				ancestor_region = get_extended_to_hier(v, region, False)
				ancestor_region = get_extended_to_hier(v, sublime.Region(ancestor_region.b, ancestor_region.b), True) # true skips blank lines
			else:
				ancestor_region = get_extended_to_hier(v, dest_region, False)

			#v.sel().clear()
			#v.sel().add(ancestor_region)
			#return

			dest_region = sublime.Region(ancestor_region.b, ancestor_region.b)
			indent = max(tabs - 1, -1)

		if above >= 2:
			indent = max(tabs - 2, -1)
		if above == 3:
			source_tree.distribute_kid0()
			# print source_tree
			indent = max(tabs - 2, -1)
		#print "tabs", tabs, "indent", indent
		# print source_tree
		txt = source_tree.get_text(indent, False)
		v.insert(edit, dest_region.a, txt)
		v.sel().clear()
		v.sel().add(sublime.Region(dest_region.a, dest_region.a + len(txt)))
		v.show_at_center(dest_region.a)
		if above == -1:
			for line in reversed(source_lines):
				v.erase(edit, v.full_line(line))
		return
	else:
		dest_region = dest_find_or_create(self, edit, source_tree if link else None)
	# v.sel().clear()
	# v.sel().add(dest_region)
	# self.view.show_at_center(dest_region.a)
	# return

# build dest tree
	dest_tree = Node("dest")
	dest_lines = v.lines(dest_region)
	dest_block = [v.substr(line) for line in dest_lines]
	dest_tree.parse(-1, dest_block)
	dest_tree.bstrip()
	# print dest_tree

# split colons
	source_tree.split_colons()
	dest_tree.split_colons()
	# print source_tree
	# print dest_tree
	# return

# clear dest lines
	for line in reversed(dest_lines):
		v.erase(edit, v.full_line(line))

#todo date
	if date is None:
		date = datetime.datetime.today().strftime('%H:%M').lower()
	# print date

# merge source into dest tree
	dest_tree.merge(source_tree, date)
	dest_tree.line = "merged"
	# print dest_tree
	dest_tree.coalesce()
	dest_tree.line = "coalesced"
	# print dest_tree
	dest_tree.join_colons(-1)
	dest_tree.line = "joined"
	# print dest_tree
	# return

# output tree to dest
	# print "----->"
	# txt = dest_tree.get_text(-1, not link)
	txt = dest_tree.get_text(-1, False)
	txt += "\n"
	v.insert(edit, dest_region.a, txt)

def move_lines(self, edit, clear_only=False, link=False, copy_only = False, above = 0, date = None):
	
	def lines_in_sel(): return sum([len(self.view.lines(r)) for r in self.view.sel()])

	v = self.view
	lines_pre = lines_in_sel()
	#if not clear_only:
	sel_hier(self, edit, False)
	lines_post = lines_in_sel()
	# print v.sel()

	if (lines_post >= lines_pre + 1 and not copy_only):
		return # to let use see selection change

	sel_orig = [r for r in v.sel()]
	for region in reversed(sel_orig):
		try:
			if region.a > region.b:
				region = sublime.Region(region.b, region.a)
			move_region(self, edit, region, clear_only, link, copy_only, above, date)
		except:
			e = sys.exc_info()[0]
			v.insert(edit, region.a, "\n% ERROR from cde.py\n% " + str(e) + "\n")
			traceback.print_exc()
			pass

class MoveLinesCommand(sublime_plugin.TextCommand):
	def run(self, edit, clear_only=False, link=False, copy_only = False, above = 0, date = None):

		move_lines(self, edit, clear_only, link, copy_only, above, date)
