cols = ["Red", "orange", "Indigo", "blue"]
cs = sorted(cols, key = str.casefold)
print(cs)